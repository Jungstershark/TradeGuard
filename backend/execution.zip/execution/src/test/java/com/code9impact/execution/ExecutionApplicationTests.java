package com.code9impact.execution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExecutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
