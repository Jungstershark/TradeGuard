package com.code9impact.analysis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnalysisApplicationTests {

	@Test
	void contextLoads() {
	}

}
